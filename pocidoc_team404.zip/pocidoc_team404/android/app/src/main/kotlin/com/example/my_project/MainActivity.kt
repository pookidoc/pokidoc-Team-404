package com.mycompany.medicalbookingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
