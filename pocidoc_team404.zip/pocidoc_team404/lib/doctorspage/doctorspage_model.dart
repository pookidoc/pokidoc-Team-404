import '/flutter_flow/flutter_flow_util.dart';
import 'doctorspage_widget.dart' show DoctorspageWidget;
import 'package:flutter/material.dart';

class DoctorspageModel extends FlutterFlowModel<DoctorspageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
