import '/flutter_flow/flutter_flow_util.dart';
import 'doctors_widget.dart' show DoctorsWidget;
import 'package:flutter/material.dart';

class DoctorsModel extends FlutterFlowModel<DoctorsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
