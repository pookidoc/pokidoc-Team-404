import '/flutter_flow/flutter_flow_util.dart';
import 'adminpanel_widget.dart' show AdminpanelWidget;
import 'package:flutter/material.dart';

class AdminpanelModel extends FlutterFlowModel<AdminpanelWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
