import '/flutter_flow/flutter_flow_util.dart';
import 'alldoctors_widget.dart' show AlldoctorsWidget;
import 'package:flutter/material.dart';

class AlldoctorsModel extends FlutterFlowModel<AlldoctorsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
