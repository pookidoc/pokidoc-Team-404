import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyAkCHEHX_y72J14coe5R9Z6rtVkF-dQA74",
            authDomain: "ennada123-9ba83.firebaseapp.com",
            projectId: "ennada123-9ba83",
            storageBucket: "ennada123-9ba83.appspot.com",
            messagingSenderId: "810000652866",
            appId: "1:810000652866:web:a51fae987100f4bf9e2bdb",
            measurementId: "G-9EM4GZ9XPY"));
  } else {
    await Firebase.initializeApp();
  }
}
