import '/flutter_flow/flutter_flow_util.dart';
import 'changeprofileimage_widget.dart' show ChangeprofileimageWidget;
import 'package:flutter/material.dart';

class ChangeprofileimageModel
    extends FlutterFlowModel<ChangeprofileimageWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
