import '/flutter_flow/flutter_flow_util.dart';
import 'markascompleted_widget.dart' show MarkascompletedWidget;
import 'package:flutter/material.dart';

class MarkascompletedModel extends FlutterFlowModel<MarkascompletedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
