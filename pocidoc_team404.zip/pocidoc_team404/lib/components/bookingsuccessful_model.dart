import '/flutter_flow/flutter_flow_util.dart';
import 'bookingsuccessful_widget.dart' show BookingsuccessfulWidget;
import 'package:flutter/material.dart';

class BookingsuccessfulModel extends FlutterFlowModel<BookingsuccessfulWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
