import '/flutter_flow/flutter_flow_util.dart';
import 'mybookings_widget.dart' show MybookingsWidget;
import 'package:flutter/material.dart';

class MybookingsModel extends FlutterFlowModel<MybookingsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
